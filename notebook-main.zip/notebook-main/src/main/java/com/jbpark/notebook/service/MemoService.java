package com.jbpark.notebook.service;

import com.jbpark.notebook.domain.Memo;

public interface MemoService {
	void addMemo(Memo memo);
}
